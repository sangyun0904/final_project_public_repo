exports.handler = async (event) => {
    // TODO implement
    const response = {
        statusCode: 200,
        body: JSON.stringify('토큰 인증 완료.'),
    };
    return response;
};